package mainpackage;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXToggleButton;
import java.io.IOException;
import static java.lang.System.exit;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StartPageController implements Initializable {   

    @FXML
    private AnchorPane rootpane;
    @FXML
    private VBox startbutton;
    @FXML
    private JFXButton optionbutton;
    @FXML
    private JFXButton exitbutton;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    
    @FXML
    private void StartTheGame(ActionEvent event) throws IOException {
      Parent pane = (AnchorPane)FXMLLoader.load(getClass().getResource("ModeChoose.fxml"));        
      Scene scene = new Scene(pane);    
      Stage curStage = (Stage) rootpane.getScene().getWindow();
      curStage.setScene(scene);
    }
    @FXML
    private void ChooseOption(ActionEvent event) throws IOException {
      Parent pane1 = (AnchorPane)FXMLLoader.load(getClass().getResource("soundmusic.fxml"));        
      Scene scene1 = new Scene(pane1);    
      Stage curStage1 = (Stage) rootpane.getScene().getWindow();
      curStage1.setScene(scene1);
    }
    @FXML
    private void exitGame(ActionEvent event) {
        System.out.println("Exit The Game");
        exit(1);
    }
    
}
