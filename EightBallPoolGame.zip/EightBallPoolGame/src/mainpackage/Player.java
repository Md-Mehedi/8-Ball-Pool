
package mainpackage;

import java.io.File;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

public class Player extends BorderPane{
    static File file=new File("Sleep Away.mp3");
    static String name=file.toURI().toString();
    static Media media=new Media(name);
    static MediaPlayer  mediaPlayer=new MediaPlayer(media);
    static MediaView mediaView=new MediaView(mediaPlayer);
    public static void setMusic(boolean condition){
        if(condition==true){
            mediaPlayer.play();
        }
        else{
            mediaPlayer.stop();
        }
    }    
}
