
package mainpackage;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXToggleButton;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class SoundmusicController implements Initializable {

    @FXML
    private AnchorPane settingpane;  
    @FXML
    private  JFXToggleButton soundbutton;
    @FXML
    private  JFXButton settingbackButton;
    @FXML
    private  JFXToggleButton musicbutton;
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        
    }    
    @FXML
    private  void togglesound(ActionEvent event) {
        if(soundbutton.isSelected()==true){
          soundbutton.setText("ON");
          //player.mediaPlayer.play();
        }
        else{
            soundbutton.setText("OFF");          
            //player.mediaPlayer.pause();
        }       
    }
    @FXML
    private void backtoMainPage(ActionEvent event) throws IOException {
     Parent pane = (AnchorPane)FXMLLoader.load(getClass().getResource("StartPage.fxml"));        
     Scene scene = new Scene(pane);    
     Stage curStage = (Stage) settingpane.getScene().getWindow();
     curStage.setScene(scene);
    }

    @FXML
    private void togglemusic(ActionEvent event) {
     if(musicbutton.isSelected()==true){
          musicbutton.setText("ON");
          Player.setMusic(true);
     }
        else{
            musicbutton.setText("OFF");
            Player.setMusic(false);
        }
    }
    
}
