
package mainpackage;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ModeChooseController implements Initializable {

    @FXML
    private AnchorPane choosemodepane;
    @FXML
    private JFXButton offflineplaybutton;
    @FXML
    private JFXButton onlineplaybutton;
    @FXML
    private JFXButton practiceplaybutton;
    @FXML
    private JFXButton backButton;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void playOfflineGame(ActionEvent event) {
    }

    @FXML
    private void playOnlineGame(ActionEvent event) {
    }

    @FXML
    private void playPracticeGame(ActionEvent event) {
    }

    @FXML
    private void backtoMainPage(ActionEvent event) throws IOException {
     Parent pane = (AnchorPane)FXMLLoader.load(getClass().getResource("StartPage.fxml"));        
     Scene scene = new Scene(pane);    
     Stage curStage = (Stage)choosemodepane.getScene().getWindow();
     curStage.setScene(scene);
    }
    
}
